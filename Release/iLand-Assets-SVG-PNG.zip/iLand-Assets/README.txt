iLand – Asset-Export

App/PNG: Original-App-Icon. Eine echte SVG-Vorlage ist im Projekt nicht vorhanden.
Marken/SVG: 100 unveränderte SVG-Originale.
Marken/PNG: dieselben Logos, transparent auf 1024 × 1024 Pixel gerendert, mit erhaltenem Seitenverhältnis und Originalfarben.
Xcode: ursprüngliche Asset-Kataloge einschließlich Contents.json.
Quellen: vorhandene Herkunftsangaben und Lizenztexte.
System: SF-Symbol-Namen der Auswahl und Swift-Farbdefinitionen. SF Symbols, Emojis und SwiftUI-Oberflächen sind systemgeneriert; keine zusätzlichen SVG-/PNG-Originale im Projekt. Persönlich importierte Nutzerbilder sind nicht Teil des Quellprojekts und daher nicht enthalten.

Die Markenbibliothek gehört zum privaten Entwicklungsstand und bleibt im App-Store-Release deaktiviert. Dieser Export ändert den Release-Umfang nicht. Herkunftsangaben sind keine pauschale Freigabe aller Markenrechte.

Screenshots liegen separat im Repository unter Release/AppStore/Screenshots.
